# Prior immutable artifacts, not newly executed here

- HEALTH original ZIP 3,318,898 B, SHA256 `f8950badc9fed8495a7dfa5fbd7849dd8b5b252cfe9dfba125b041fe7e1289f1`: https://drive.google.com/file/d/1GbegbPtjIseOp-p06-7KGrxq0DWsId_x/view
- Previous independent VERIFICATION ZIP 4,640,886 B, SHA256 `d4eca534a98cc5cb5222a05fed961cc05e6d3f5bd8fa472ad15df24229b4a599`: https://drive.google.com/file/d/1pTfdnjhiBamHn406lcfSsdT5uEQgPB_x/view
- PACHINKO original ZIP 14,605,595 B, SHA256 `f706afa7b934c87405a67898dfc48ca28753f3a140d26fc80fe87ac15728bd4e`: https://drive.google.com/file/d/16okmdisZ5rnBDP8Oh_W63MNwXTehC019/view

All three actually read and fully revalidated current session: ZIP CRC PASS, exact SHA and root manifest payload entries 1299/1299, 1047/1047, 514/514. Each root manifest is not a listed payload itself. `PROVENANCE/ARCHIVE_INTAKE_*.json` records check details. `PRIOR_INDEPENDENT_VERIFICATION_ANALYSIS` is a **copy of old fixed-sha model**, not a fresh proof. Source snapshots/build listings in this ZIP come from exact previously independently built and manifest-verified HEALTH LAB independent Verification, and are not a new DASM run. No original ZIP is modified.
