#!/usr/bin/env python3
"""Independent immutable evidence staging, with ZIP full manifest, CRC, all payload hashes."""
from pathlib import Path
import shutil,hashlib,zipfile,os,json,sys,subprocess
BASE=Path('/mnt/data/LAB_FINAL_TARGETED');ROOT=Path('/mnt/data/MELLANRUM_HEALTH_LAB_FINAL_TARGETED_VERIFICATION_EVIDENCE_2026-11-25');ZIP=Path('/mnt/data/MELLANRUM_HEALTH_LAB_FINAL_TARGETED_VERIFICATION_EVIDENCE_2026-11-25.zip')
assert ROOT!=BASE
if ROOT.exists():shutil.rmtree(ROOT)
ROOT.mkdir()

def put(a,b):
 src=BASE/a if not str(a).startswith('/') else Path(a);dest=ROOT/b;assert src.is_file(),src;dest.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(src,dest)

def tree(a,b):
 s=BASE/a;assert s.is_dir(),s
 for p in s.rglob('*'):
  if p.is_file():put(p,b/p.relative_to(s))

for f in ['00_MAIN_IV_HANDOFF.md','01_FINAL_TARGETED_VERIFICATION_REPORT.md','03_REMAINING_RISK_DISPOSITION.md','04_REPRODUCE.md','05_FAILURE_REPRODUCTIONS.md']:put(f,f)
put('ANALYSIS/TEST_MATRIX.csv','02_TEST_MATRIX.csv')
put('verification/REFERENCE/RC1.bin','ROMS/RC1.bin')
put('verification/SPECIMEN/LAB_STACK_INLINE_PADDED_B_EXPERIMENT_ONLY.bin','ROMS/LAB_BEST.bin')
for v in ['RC1','LAB_BEST']:tree(f'verification/SOURCE_SNAPSHOT/{v}',f'SOURCE_SNAPSHOT/{v}')
for v in ['RC1_B','LAB_BEST_B']:
  which='RC1' if v=='RC1_B' else 'LAB_BEST';s=BASE/f'verification/BUILD/{v}'
  for f in ['build_stdout.log','build_stderr.log','BUILD_IDENTITY.json','rom/src/main.asm','rom/f6/build_f6.py','rom/f6/bank0_score.asm','rom/f6/bank1_score.asm','rom/f6/bank2_score.asm']:
   if (s/f).exists():put(s/f,f'BUILD_OR_PRIOR_BUILD_REFERENCE/{v}/{f}')
  for ext in ['lst','sym']:
   for bank in range(4):put(s/f'build/{which}/bank{bank}.{ext}',f'BUILD_OR_PRIOR_BUILD_REFERENCE/{v}/bank{bank}.{ext}')
  put(s/f'build/{which}/ROM_16K_BUILD.json',f'BUILD_OR_PRIOR_BUILD_REFERENCE/{v}/ROM_16K_BUILD.json')
  put(s/f'build/{which}/SHA256SUMS',f'BUILD_OR_PRIOR_BUILD_REFERENCE/{v}/ORIGINAL_BUILD_SHA256SUMS')
# New analysis and scripts
for s in (BASE/'ANALYSIS').glob('*'):
 if s.is_file():put(s,f'ANALYSIS/{s.name}')
for s in (BASE/'SCRIPTS').glob('*'):
 if s.is_file():put(s,f'SCRIPTS/{s.name}')
put('health/MELLANRUM_HEALTH_OPTIMIZATION_LAB_EVIDENCE/TEST_TOOLS/libretro_stella_capture.py','SCRIPTS/PRIOR_HEALTH_ORIGINAL_libretro_stella_capture.py')
put('verification/EVIDENCE/GOPHER_FULL/commands.txt','TEST_INPUTS/PRIOR_GOPHER_FULL_CONTROLLER_COMMANDS.txt')
for v in ['LAB','RC1']:
 put(f'work/logs/natural_bank1_{v}_raw.log',f'EVIDENCE/BANK1_NATURAL/natural_bank1_{v}_raw.log')
 rawscript='natural_bank1_LAB.script' if v=='LAB' else 'natural_bank1_RC1_corrected.script'
 put(f'work/scripts/{rawscript}',f'EVIDENCE/BANK1_NATURAL/natural_bank1_{v}.script')
 put(f'ANALYSIS/NATURAL_BANK1_{v}.json',f'EVIDENCE/BANK1_NATURAL/natural_bank1_{v}.json')
 put(f'work/logs/natural_owl_continuation_{v}_raw.log',f'EVIDENCE/OWL_CONTINUATION/natural_owl_continuation_{v}_raw.log')
 put(f'work/scripts/natural_owl_continuation_{v}.script',f'EVIDENCE/OWL_CONTINUATION/natural_owl_continuation_{v}.script')
 put(f'work/logs/roomload_fullchain_{v}_raw.log',f'EVIDENCE/ROOM_LOAD_TIMER/roomload_fullchain_{v}_raw.log')
 put(f'work/scripts/natural_roomload_fullchain_{v}.script',f'EVIDENCE/ROOM_LOAD_TIMER/natural_roomload_fullchain_{v}.script')
 for run in [f'natural_bank1_{v}_exit.txt',f'natural_owl_continuation_{v}_exit.txt',f'roomload_fullchain_{v}_exit.txt']:
  if (BASE/'work/logs'/run).exists():put(f'work/logs/{run}',f'EVIDENCE/EXIT_CODES/{run}')
for v in ('LAB','RC1','PR47'):
 put(f'work/logs/natural_x9_instrumented_{v}.log',f'EVIDENCE/NEGATIVE_CONTROLS/natural_x9_instrumented_{v}.log')
 put(f'work/scripts/natural_x9_instrumented_{v}.script',f'EVIDENCE/NEGATIVE_CONTROLS/natural_x9_instrumented_{v}.script')
# PR47 negative reference only; no modifications to candidate/reference ROMs.
put('work/PR47_NEGATIVE.bin','EVIDENCE/NEGATIVE_CONTROLS/PR47_NEGATIVE_CONTROL_ONLY.bin')
# Original 10 experimental Gopher runs, including individual raw log and command files
for p in (BASE/'EVIDENCE/TERMINAL_RASTER').rglob('*'):
 if p.is_file():put(p,f'EVIDENCE/TERMINAL_RASTER/{p.relative_to(BASE/'EVIDENCE/TERMINAL_RASTER')}')
# Four genuine audio sessions and dual real CPU/TIA sound-write sessions
for p in (BASE/'EVIDENCE/FRI_AUDIO').rglob('*'):
 if p.is_file():put(p,f'EVIDENCE/FRI_AUDIO/{p.relative_to(BASE/'EVIDENCE/FRI_AUDIO')}')
# Invalid pilots and diagnostic parser harness logs, all distinct from product evidence
for f in ['natural_bank1_RC1_wrong_PC_INVALID.log','parse_natural_roomload_chain.stderr','parse_natural_roomload_chain.stdout','generate_final_machine_ledgers.stdout','generate_final_machine_ledgers.stderr','fri_audio_runner.log','compare_fri_pcm_oracle.stdout','compare_fri_pcm_oracle.stderr','roomload_fullchain_LAB_supervisor.log','roomload_fullchain_RC1_supervisor.log']:
 if (BASE/'work/logs'/f).exists():put(f'work/logs/{f}',f'EVIDENCE/INVALID_PILOTS_AND_TIMEOUTS/{f}' if 'INVALID' in f or 'stderr' in f else f'EVIDENCE/PROCESS_LOGS/{f}')
# Prior referenced exact source ledgers: not counted as newly measured
for f in ['CFG_LAB_BEST.json','CFG_RC1.json','CYCLE_AND_TIA_DEADLINES.json','TITLE_64_TIA_REAL_BUS_DEADLINES.json','RELOCATION_DOMAIN_AUDIT.csv']:
 put(f'verification/ANALYSIS/{f}',f'PRIOR_INDEPENDENT_VERIFICATION_ANALYSIS/{f}')
for who in ['health','verification','pachinko']:put(f'intake_{who}.json',f'PROVENANCE/ARCHIVE_INTAKE_{who}.json')
# Metadata data
romsha={'RC1':'456005ed691860b32c44b79f2a71666f622b005f5a798eadf9b549c59cff13bd','LAB_BEST':'8a59b84eb5151f78d40e6943c854d7e42c166b531aee3d40432182d32dcdf03b','PR47_NEGATIVE_CONTROL':'5b8315512bf274398c3d2f4622dc96e081d1481d93b2c8adaf6411de2e2a0ed5'}
for key,file in [('RC1','ROMS/RC1.bin'),('LAB_BEST','ROMS/LAB_BEST.bin'),('PR47_NEGATIVE_CONTROL','EVIDENCE/NEGATIVE_CONTROLS/PR47_NEGATIVE_CONTROL_ONLY.bin')]:
 p=ROOT/file;assert p.stat().st_size==16384 and hashlib.sha256(p.read_bytes()).hexdigest()==romsha[key]
source_sha={'RC1':'758d5ad2eb14942d4b2ca6263aa2942ba61f927285291fa51bbedf4e8ff1f01d','LAB_BEST':'3246d67a40470454eb56c38f2f4c32fb34ccb4ff38ed796ccb10cf00a647d53e'}
for k,v in source_sha.items():assert hashlib.sha256((ROOT/f'SOURCE_SNAPSHOT/{k}/rom/src/main.asm').read_bytes()).hexdigest()==v
(ROOT/'PROVENANCE/IDENTITIES.json').write_text(json.dumps({'project':'MELLANRUM: SKOGEN SOM LYSSNAR','role':'INDEPENDENT_VERIFICATION','date':'2026-11-25','user_authorized_scope':'Final targeted HEALTH LAB source-immutable verification; not product code integration, no RC2, no timer feasibility or implementation','RC1_PR49_HEAD':'d013a0f82621d46ad12674a4a8e944bf005cd9c3','RC1_product_commit':'7b400ad8678e8341a26f65cc757b1eb762654c83','ROM_SHA256':romsha,'source_main_asm_SHA256':source_sha,'mapper':'NTSC F6 4x4096 16,384 bytes','final_status':'FINAL_TARGETED_VERIFICATION_PASS_BOUNDED','global_all_path_timing':'INCONCLUSIVE','FRI_strict_PCM_AB':'INCONCLUSIVE','human_and_physical':'NOT_RUN'},indent=2)+'\n')
(rootpr:=ROOT/'PROVENANCE/TOOLS.json').write_text(json.dumps({'gopher_native_source_commit':'74c544203378c1448a33c29bc8b4586079b050f4','gopher_native_elf_sha256':'7b12dff57fcb73154122d2477f35d9c8ae8b344649bc0faa8ff6f5663c70470b','stella_libretro_version':'8.0_pre 8dd5600','stella_core_elf_sha256':'2130ed1153cef66ef3f34bf9063f675f1f3342bc18320eb9ae5101743e3042df','dasm_prior_native_version':'2.20.14.1','dasm_sha256':'cfb23732297a4fe1c8d4a78d44206037d97733aedb2772503bbf029a4aa91291','current_fresh_DASM_build':'NOT_RUN, prior independent builds retained with exact build logs/syms/listings','gopher_native_actual_hash_check':hashlib.sha256((BASE/'work/gopher2600_pinned').read_bytes()).hexdigest(),'stella_native_actual_hash_check':hashlib.sha256((BASE/'pachinko/TOOLS/stella_libretro.so').read_bytes()).hexdigest(),'runtime':'linux x86_64 original pinned tools; new experiments Gopher real CPU/TIA/RIOT bus and Stella raw libretro callbacks; no physical Atari'},indent=2)+'\n')
# Machine run provenance: original commands/logs/tool pins/sha checks
runs=[]
for p in sorted((ROOT/'EVIDENCE').rglob('*.log')):
 if 'INVALID' in p.name:classification='FAIL_HARNESS_CORRECTED_INVALID_PILOT'
 elif 'natural' in p.name or 'roomload' in p.name:classification='NATURAL_CONTROLLER_OR_SOURCE_GUIDED_CONTROLLER (see scenario README)'
 elif 'fri_' in p.name:classification='NATURAL_CONTROLLER'
 else:classification='CHECK_TEST_MATRIX_FOR_FORCE_STATUS'
 runs.append({'raw_trace_path':str(p.relative_to(ROOT)),'sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'bytes':p.stat().st_size,'classification':classification})
(ROOT/'PROVENANCE/ORIGINAL_RAW_LOG_HASHES.json').write_text(json.dumps({'count':len(runs),'logs':runs},indent=2)+'\n')
# Final resumable status after finished assertions
(ROOT/'RESUME_STATE.json').write_text(json.dumps({'as_of_utc':'2026-11-25','status':'COMPLETED','specimen_lab_sha256':romsha['LAB_BEST'],'rc1_sha256':romsha['RC1'],'completed':['3 prior archive SHA/CRC/manifest intakes','1 full natural lab bank1 with CPU bus stack + matched RC1','natural OwlTryNext branch and first visible PF through real timer','4 natural indexed pagecross roomloads with full RC1/LAB INTIM/VBLANK/PF tracing','natural fireX9 PR47 negative control and matched RC1/LAB','10 LAB terminal/HUD native 262-line risk cases, 9 forced','4 fresh 2400-frame Stella FRI PCM processes','43 real Gopher FRI sound register bus frames each ROM, six shifted sound writes'], 'invalid_pilots':['RC1 first bank1 caller PC wrong, corrected valid rerun','roomload parser initial multiple next-PC match, corrected against original raw'], 'remaining_inconclusive':['Global combined terminal WSYNC/TIA all-reachable-state proof','FRI same-ROM raw PCM nondeterminism, cannot attribute AB playback difference'], 'not_run':['Second distinct natural actII bank1 echo-phase call','Physical original Atari and RetroN77','Human cold-play, original art/audio listening','No new timer feasibility/code/release'], 'next': 'No active further work; MAIN IV/user separately decide technical base. No background job pending or promised.'},indent=2)+'\n')
# Copy exact old original authors' README/archive provenance labels, not alter their original files
(ROOT/'PRIOR_ARCHIVE_REFERENCE.md').write_text('''# Prior immutable artifacts, not newly executed here\n\n- HEALTH original ZIP 3,318,898 B, SHA256 `f8950badc9fed8495a7dfa5fbd7849dd8b5b252cfe9dfba125b041fe7e1289f1`: https://drive.google.com/file/d/1GbegbPtjIseOp-p06-7KGrxq0DWsId_x/view\n- Previous independent VERIFICATION ZIP 4,640,886 B, SHA256 `d4eca534a98cc5cb5222a05fed961cc05e6d3f5bd8fa472ad15df24229b4a599`: https://drive.google.com/file/d/1pTfdnjhiBamHn406lcfSsdT5uEQgPB_x/view\n- PACHINKO original ZIP 14,605,595 B, SHA256 `f706afa7b934c87405a67898dfc48ca28753f3a140d26fc80fe87ac15728bd4e`: https://drive.google.com/file/d/16okmdisZ5rnBDP8Oh_W63MNwXTehC019/view\n\nAll three actually read and fully revalidated current session: ZIP CRC PASS, exact SHA and root manifest payload entries 1299/1299, 1047/1047, 514/514. Each root manifest is not a listed payload itself. `PROVENANCE/ARCHIVE_INTAKE_*.json` records check details. `PRIOR_INDEPENDENT_VERIFICATION_ANALYSIS` is a **copy of old fixed-sha model**, not a fresh proof. Source snapshots/build listings in this ZIP come from exact previously independently built and manifest-verified HEALTH LAB independent Verification, and are not a new DASM run. No original ZIP is modified.\n''')
# Main README
(ROOT/'README.md').write_text('''# MELLANRUM HEALTH LAB – FINAL TARGETED INDEPENDENT VERIFICATION, 2026-11-25\n\n**Status:** `FINAL_TARGETED_VERIFICATION_PASS_BOUNDED`, separate `GLOBAL_ALL_PATH_TIMING_INCONCLUSIVE` and `FRI_RAW_PCM_STRICT_AB_INCONCLUSIVE`, `HUMAN_AND_PHYSICAL_NOT_RUN`. **Not RC2, not release, no product code edits.**\n\nRead `00_MAIN_IV_HANDOFF.md` for the decision, `01_FINAL_TARGETED_VERIFICATION_REPORT.md` for complete technical adjudication (including a newly measured 3-colorclock audio bus delta), `02_TEST_MATRIX.csv` for every run and scope, `03_REMAINING_RISK_DISPOSITION.md`, `04_REPRODUCE.md`, `05_FAILURE_REPRODUCTIONS.md`, and `RESUME_STATE.json` for resumability.\n\nAll raw evidence captured in this new work is in EVIDENCE/* with original native Gopher command scripts, raw CPU/TIA/RIOT bus events, Stella true WAV and callback metadata; model ledgers in `ANALYSIS/*`. Original frozen RC1/LAB ROM bytes and exact source are under ROMS/SOURCE_SNAPSHOT. `BUILD_OR_PRIOR_BUILD_REFERENCE` are **previous** independent DASM outputs, preserved not counted as fresh builds. Three prior ZIPs referenced by their exact hashes, never misrepresented as new work.\n\nMain evidence distinctions: 1 natural actII complete bank1 matched call, 4 naturally transported roomload cycle deltas with full RIOT INTIM and PF bus A/B, 1 natural taken OwlTryNext branch with 6 earlier same-value TIA sound register writes, 1 natural HUD fireX9 plus PR47 263-line negative and 9 forced state kernel diagnostics, 4 same-input FRI Stella captures showing within-ROM PCM nondeterminism. No new proven release-blocker. Global combined paths not formally closed.\n\n**Full manifest:** `SHA256SUMS.txt` lists every other payload exactly once; test via `sha256sum -c SHA256SUMS.txt` after extraction. The manifest itself is excluded intentionally. ZIP CRC independently verified.\n''')
# SHA256 payload manifest and deterministic sorted compressed ZIP
files=sorted(p for p in ROOT.rglob('*') if p.is_file()); assert not any(p.name=='SHA256SUMS.txt' for p in files)
manifest=''.join(f'{hashlib.sha256(p.read_bytes()).hexdigest()}  {p.relative_to(ROOT).as_posix()}\n' for p in files)
(ROOT/'SHA256SUMS.txt').write_text(manifest)
assert len(manifest.splitlines())==len(files)
if ZIP.exists():ZIP.unlink()
with zipfile.ZipFile(ZIP,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=7,allowZip64=True) as z:
 for p in sorted(ROOT.rglob('*')):
  if p.is_file():z.write(p,arcname=p.relative_to(ROOT).as_posix())
# Reread ZIP and validate CRC, manifest, unsafe names, duplicate names, complete payload
with zipfile.ZipFile(ZIP) as z:
 names=z.namelist();assert len(set(names))==len(names),(len(names),len(set(names)));assert z.testzip() is None
 assert all(n==str(Path(n)) and not n.startswith('/') and '..' not in Path(n).parts for n in names)
 raws=z.read('SHA256SUMS.txt').decode().splitlines();assert len(raws)==len(names)-1
 seen=[]
 for line in raws:
  digest,relative=line.split('  ',1);seen.append(relative);assert hashlib.sha256(z.read(relative)).hexdigest()==digest,(relative,'SHA FAIL')
 assert sorted(seen)==sorted(n for n in names if n!='SHA256SUMS.txt')
h=hashlib.sha256(ZIP.read_bytes()).hexdigest()
print(json.dumps({'delivery_dir':str(ROOT),'zip_path':str(ZIP),'zip_bytes':ZIP.stat().st_size,'zip_sha256':h,'zip_members':len(names),'manifest_payloads':len(raws),'crc':'PASS','source_rom_identity':'PASS','complete_manifest':'PASS','raw_log_count':len(runs)},indent=2))
(ROOT/'PROVENANCE/FINAL_ARCHIVE_IDENTITY.json').write_text(json.dumps({'zip_filename':ZIP.name,'archive_sha256':h,'archive_bytes':ZIP.stat().st_size,'entries':len(names),'manifest_payloads':len(raws),'crc':'PASS'},indent=2)+'\n')
# NB: identity JSON is outside finalized ZIP and must not be represented as an included manifest member.
