#!/usr/bin/env python3
"""Independent parser of original native Gopher2600 debugger CPU+real bus traces.
Follows four controller-reached room indices, before/after local indexed reads,
timer initial and final CPU INTIM reads, real VBLANK bus and visible PF writes.
Never fills in missing evidence with a PASS/default value.
"""
from pathlib import Path
import re,hashlib,json,csv
ROOT=Path('/mnt/data/LAB_FINAL_TARGETED')
SRC=ROOT/'work/logs';OUT=ROOT/'ANALYSIS';OUT.mkdir(exist_ok=True)
TARGETS=[(1,964,'GeoMapHi'),(2,2497,'GeoMapHi'),(4,4483,'RoomStoneY'),(5,5872,'RoomStoneY')]
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def pos(t):
 m=re.search(r'FR=(\d+) SL=(\d+) CL=(-?\d+)',t)
 if not m:raise ValueError('Missing real clock position')
 return {'frame':int(m[1]),'scanline':int(m[2]),'cl':int(m[3]),'colorclock':int(m[3])+68}
def events(s,pattern):
 return [{'position':pos(s[max(0,m.start()-90):m.start()]),'value_hex':m.group(1)} for m in re.finditer(pattern,s,re.I)]
def grab(s,pc):
 m=re.search(r'^break on PC->0x'+pc+r'[^\n]*\nPC=([^\n]+)\nFR=([^\n]+)',s,re.M)
 if not m:raise ValueError('missing PC '+pc)
 return {'registers':m[1],'position':pos('FR='+m[2])}
def parse(kind):
 file=SRC/f'roomload_fullchain_{kind}_raw.log'; assert (SRC/f'roomload_fullchain_{kind}_exit.txt').read_text().strip()=='0'
 s=file.read_text();info={'variant':kind,'raw_file':str(file.relative_to(ROOT)),'raw_sha256':sha(file),'events':[]}
 for x,frame,key in TARGETS:
  marker=f'break on PC->0xf2d5 & Bank->3 & X->0x{x:02x}'
  if s.count(marker)!=1:raise ValueError((kind,marker,s.count(marker)))
  i=s.index(marker);j=s.index(f'break on Frame->{frame+1}',i);seg=s[i:j]
  before=s[max(i-1000,0):i]
  pre=events(before,r'write 0x([0-9a-f]+) to 0x0296 \(TIM64T\)')
  if not pre:raise ValueError('missing timer write '+str(frame))
  p=grab(seg,'f2d5');q=grab(seg,'f2ed');w=grab(seg,'f05e');end=grab(seg,'f063');ret=grab(seg,'f790' if kind=='LAB' else 'f78e')
  instrs={}
  for pc,reg in [('f2d5',p),('f2ed',q)]:
   z=seg.index(f'break on PC->0x{pc}');body=seg[z:z+600]
   nextpc='f2d8' if pc=='f2d5' else 'f2f0'
   times=list(re.finditer(r'PC='+nextpc+r' A=[^\n]+\n(FR=\d+ SL=\d+ CL=-?\d+)',body))
   if len(times)!=1:raise ValueError('missing instruction end '+pc+' '+kind+' '+str(frame))
   stop=pos(times[0].group(1));start=reg['position']
   clocks=(stop['frame']-start['frame'])*262*228+(stop['scanline']-start['scanline'])*228+stop['colorclock']-start['colorclock']
   instrs[pc]={'start':start,'finish':stop,'cost_cpu_cycles':clocks//3,'cycles_exact':clocks%3==0}
  if not all(a['cycles_exact'] for a in instrs.values()):raise ValueError('invalid CPU cycle delta')
  reads=events(seg,r'read 0x([0-9a-f]+) from 0x0284 \(INTIM\)');
  blank=events(seg,r'write 0x([0-9a-f]+) to 0x0001 \(VBLANK\)');
  pf={r:events(seg,fr'write 0x([0-9a-f]+) to 0x{a:04x} \(PF{r}\)') for r,a in [('0',13),('1',14),('2',15)]}
  if not reads or not blank or any(not v for v in pf.values()):raise ValueError('missing bus event '+str(frame))
  real_blank=[v for v in blank if v['value_hex']=='00']
  if not real_blank:raise ValueError('missing OFF VBLANK')
  m=re.search(rf'break on Frame->{frame+1}\ntop: (\d+), bottom: (\d+), total: (\d+)',s[j:j+130]);
  if not m:raise ValueError('missing full frame '+str(frame))
  row={'scenario_id':f'ROOM_LOAD_X{x}_{key}_FRAME{frame}', 'evidence_class':'SOURCE_GUIDED_CONTROLLER / NATURAL_ADVANCE', 'rom_sha256':'8a59b84eb5151f78d40e6943c854d7e42c166b531aee3d40432182d32dcdf03b' if kind=='LAB' else '456005ed691860b32c44b79f2a71666f622b005f5a798eadf9b549c59cff13bd', 'room_index':x,'frame':frame, 'context_from_break':p['registers'],'indexed_reads':instrs,'timer_last_write_pre_event':pre[-1],'wait_vblank_entry':w['position'],'first_relevant_intim_cpu_read':reads[0], 'intim_real_cpu_reads_count':len(reads),'wait_vblank_exit':end['position'],'vblank_0_real_write':real_blank[0], 'renderer_entry':ret['position'],'first_visible_pf_writes':{r:v[0] for r,v in pf.items()},'raster_scanlines':int(m.group(3)),'all_captured_pf_writes_count':{k:len(v) for k,v in pf.items()},'status':'PASS_BOUNDED' if int(m.group(3))==262 else 'FAIL', 'provenance':info['raw_file']}
  info['events'].append(row)
 return info
pair=[parse('RC1'),parse('LAB')]
out={x['variant']:x for x in pair}
comps=[]
for rc,lb in zip(out['RC1']['events'],out['LAB']['events']):
 assert rc['room_index']==lb['room_index'] and rc['frame']==lb['frame']
 title=rc['scenario_id'];diffs={}
 for k in ('wait_vblank_entry','first_relevant_intim_cpu_read','wait_vblank_exit','vblank_0_real_write','renderer_entry'):
  a,b=rc[k],lb[k];diffs[k]=a==b
 for n in ('0','1','2'):
  diffs['PF'+n+'_first_written']=rc['first_visible_pf_writes'][n]==lb['first_visible_pf_writes'][n]
 diffs['all_pf_write_counts']=rc['all_captured_pf_writes_count']==lb['all_captured_pf_writes_count']
 local={pc:{'RC1':rc['indexed_reads'][pc]['cost_cpu_cycles'],'LAB':lb['indexed_reads'][pc]['cost_cpu_cycles']} for pc in ('f2d5','f2ed')}
 comps.append({'scenario_id':title,'room_index':rc['room_index'],'frame':rc['frame'],'local_indexed_cycles':local,'differential_check_fields':diffs,'first_intim_rc1':rc['first_relevant_intim_cpu_read'],'first_intim_lab':lb['first_relevant_intim_cpu_read'],'room_load_reached_naturally':True,'both_raster_262':rc['raster_scanlines']==lb['raster_scanlines']==262,'bus_timer_and_PF_alignment':all(diffs.values()),'status':'PASS_BOUNDED' if all(diffs.values()) else 'DIFFERENCE_REQUIRE_EXPLANATION'})
(OUT/'NATURAL_ROOMLOAD_A_B_TIMERS_AND_BUS.json').write_text(json.dumps({'variants':out,'comparisons':comps},indent=2)+'\n')
with open(OUT/'NATURAL_ROOMLOAD_A_B_SUMMARY.csv','w',newline='') as f:
 w=csv.DictWriter(f,fieldnames=['scenario_id','room_index','frame','f2d5_RC1','f2d5_LAB','f2ed_RC1','f2ed_LAB','intim_RC1','intim_LAB','wait_blank_sync','renderer_sync','pf_bus_sync','both_raster_262','status']);w.writeheader()
 for r in comps:
  def g(field):return r['differential_check_fields'][field]
  w.writerow({'scenario_id':r['scenario_id'],'room_index':r['room_index'],'frame':r['frame'],'f2d5_RC1':r['local_indexed_cycles']['f2d5']['RC1'],'f2d5_LAB':r['local_indexed_cycles']['f2d5']['LAB'],'f2ed_RC1':r['local_indexed_cycles']['f2ed']['RC1'],'f2ed_LAB':r['local_indexed_cycles']['f2ed']['LAB'],'intim_RC1':r['first_intim_rc1']['value_hex'],'intim_LAB':r['first_intim_lab']['value_hex'],'wait_blank_sync':g('wait_vblank_entry') and g('wait_vblank_exit'),'renderer_sync':g('renderer_entry'),'pf_bus_sync':all(g('PF'+str(i)+'_first_written') for i in range(3)),'both_raster_262':r['both_raster_262'],'status':r['status']})
print(json.dumps({'scenarios':len(comps),'summary':comps},indent=2))
