#!/usr/bin/env python3
"""Assemble explicit status ledgers from prior immutable evidence and new raw data.
No default PASS; all successful rows require raw files and assertions.
"""
from pathlib import Path
import json,csv,hashlib,re,shutil
ROOT=Path('/mnt/data/LAB_FINAL_TARGETED');an=ROOT/'ANALYSIS';an.mkdir(exist_ok=True)
RCS='456005ed691860b32c44b79f2a71666f622b005f5a798eadf9b549c59cff13bd';LAB='8a59b84eb5151f78d40e6943c854d7e42c166b531aee3d40432182d32dcdf03b';GO='7b12dff57fcb73154122d2477f35d9c8ae8b344649bc0faa8ff6f5663c70470b';ST='2130ed1153cef66ef3f34bf9063f675f1f3342bc18320eb9ae5101743e3042df'
def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def csvout(name,rows):
 keys=[]
 for row in rows:
  for k in row:
   if k not in keys:keys.append(k)
 with (an/name).open('w',newline='') as f:
  w=csv.DictWriter(f,fieldnames=keys);w.writeheader();w.writerows(rows)
# Bank all real stack bus accesses, physical aliases, frame context
bank=[]
for var in ('RC1','LAB'):
 j=json.loads((an/f'NATURAL_BANK1_{var}.json').read_text());assert j['valid_natural'] and not j['errors'] and j['frames_262']==1 and j['event_frame_indices']==[5880]
 for group,kind in [('stack_bus_writes','CPU_STACK_WRITE'),('stack_bus_reads','CPU_STACK_READ'),('bank_hotspot_CPU_reads','CPU_CARTRIDGE_BANK_READ')]:
  for i,e in enumerate(j[group]):
   bank.append({'scenario_id':'NATURAL_ACTII_II01_BANK1','variant':var,'rom_sha256':RCS if var=='RC1' else LAB,'emulator_sha256':GO,'evidence_class':'SOURCE_GUIDED_CONTROLLER','frame':e['frame'],'scanline':e['scanline'],'actual_colorclock':e['colorclock'],'bank_or_pc_context':e['pc'],'SP_at_access':e['sp'],'bus_direction':kind,'physical_bus_address_hex':e['addr'],'bus_data_hex':e['data'],'riot_mirror_low_byte':e['addr'][2:] if e['addr'].startswith('01') else '','raw_sha256':j['raw_sha256'],'raw_trace_path':'EVIDENCE/BANK1_NATURAL/natural_bank1_'+var+'_raw.log','status':'PASS_BOUNDED'})
csvout('STACK_BANK_EVENT_LEDGER.csv',bank)
# Cycle+timer+TIA matrix from direct genuine Gopher bus traces
rooms=json.loads((an/'NATURAL_ROOMLOAD_A_B_TIMERS_AND_BUS.json').read_text());rrows=[]
for c in rooms['comparisons']:
 for var in ('RC1','LAB'):
  r=next(x for x in rooms['variants'][var]['events'] if x['frame']==c['frame'])
  assert r['raster_scanlines']==262 and c['bus_timer_and_PF_alignment'];q=r['first_relevant_intim_cpu_read'];pre=r['timer_last_write_pre_event']
  rrows.append({'scenario_id':c['scenario_id'],'variant':var,'rom_sha256':RCS if var=='RC1' else LAB,'tool_sha256':GO,'evidence_class':'SOURCE_GUIDED_CONTROLLER','natural_room_index':c['room_index'],'frame':c['frame'],'F2D5_lda_RoomStoneY_cycles':r['indexed_reads']['f2d5']['cost_cpu_cycles'],'F2ED_lda_GeoMapHi_cycles':r['indexed_reads']['f2ed']['cost_cpu_cycles'],'previous_timer_0x296_write_value':pre['value_hex'],'previous_timer_write_frame':pre['position']['frame'],'previous_timer_write_scanline':pre['position']['scanline'],'previous_timer_write_colorclock':pre['position']['colorclock'],'wait_vblank_entry_sl':r['wait_vblank_entry']['scanline'],'wait_vblank_entry_cc':r['wait_vblank_entry']['colorclock'],'first_CPU_INTIM_read':q['value_hex'],'first_CPU_INTIM_read_sl':q['position']['scanline'],'first_CPU_INTIM_read_cc':q['position']['colorclock'],'wait_end_sl':r['wait_vblank_exit']['scanline'],'wait_end_cc':r['wait_vblank_exit']['colorclock'],'VBLANK_OFF_SL':r['vblank_0_real_write']['position']['scanline'],'VBLANK_OFF_CC':r['vblank_0_real_write']['position']['colorclock'],'first_visible_PF0_cc':r['first_visible_pf_writes']['0']['position']['colorclock'],'first_visible_PF1_cc':r['first_visible_pf_writes']['1']['position']['colorclock'],'first_visible_PF2_cc':r['first_visible_pf_writes']['2']['position']['colorclock'],'scanlines':r['raster_scanlines'],'reported_tia_writes':sum(r['all_captured_pf_writes_count'].values()),'raw_trace_path':r['provenance'],'status':'PASS_BOUNDED'})
csvout('TIMER_VBLANK_LEDGER.csv',rrows)
# beam matrix (genuine native 10 risk scenarios; diagnostic vs natural explicit)
beam=[]
for p in sorted((ROOT/'EVIDENCE/TERMINAL_RASTER').glob('*/result.json')):
 r=json.loads(p.read_text());assert r['exit']==0 and r['status']=='PASS_BOUNDED' and all(x==262 for x in r['raster_totals']);
 for h in r['resp0_bus']:
  beam.append({'scenario_id':r['scenario'],'rom_sha256':r['rom_sha256'],'tool_sha256':r['emulator_sha256'],'evidence_class':r['classification'],'state_forcing_commands':';'.join(r['forced_commands']),'tested_frame_scanlines':';'.join(map(str,r['raster_totals'])),'register':'RESP0','frame':h.get('frame'),'scanline':h.get('scanline'),'actual_colorclock':h.get('colorclock'),'PC':h.get('pc'),'actual_data_hex':h.get('data'),'cycles_to_WSYNC_boundary':76,'minimum_observed_margin_CPU_cycles':0,'source_domain': 'live fireX9; verified same room-state or diagnostic RAM-forced statuses','status':r['status'],'raw_trace_path':str((p.parent/'raw.log').relative_to(ROOT))})
csvout('BEAM_DEADLINE_LEDGER.csv',beam)
# concise risk/diff matrix with grounded source-level and dynamic results
matrix=[
{'id':'BCS_OwlTryNext','valid_index':'natural FR2142; taken CARRY=1','local_delta_cpu_cycles':-1,'observed_next_timer':'first INTIM20; WaitVB entry SL18 CL-41','first_visible_TIA':'PF0 SL35 CL76 same RC1/LAB','other_bus_effects':'Six audio AUDxx writes in FR2142 exactly 3 colorclocks earlier LAB; values identical','status':'PASS_BOUNDED for visible / ACTUAL_AUDIO_TIMING_DELTA','source':'EVIDENCE/OWL_CONTINUATION/* + EVIDENCE/FRI_AUDIO/fri_tia_audio_registers_*'},
{'id':'GeoMapHi_X1','valid_index':'I-02 room index1 FR964','local_delta_cpu_cycles':+1,'observed_next_timer':'first INTIM0x0c, common WaitVB exit SL34 CL88','first_visible_TIA':'PF0 SL35 CL70 same','other_bus_effects':'No visible PF timing difference in captured scene','status':'PASS_BOUNDED','source':'ANALYSIS/NATURAL_ROOMLOAD_A_B_TIMERS_AND_BUS.json'},
{'id':'GeoMapHi_X2','valid_index':'I-03 room index2 FR2497','local_delta_cpu_cycles':+1,'observed_next_timer':'first INTIM0x0c, common WaitVB exit SL34 CL88','first_visible_TIA':'PF0 SL35 CL70 same','other_bus_effects':'No visible PF timing difference in captured scene','status':'PASS_BOUNDED','source':'ANALYSIS/NATURAL_ROOMLOAD_A_B_TIMERS_AND_BUS.json'},
{'id':'RoomStoneY_X4','valid_index':'I-05 room index4 FR4483','local_delta_cpu_cycles':+1,'observed_next_timer':'first INTIM0x0c, common WaitVB exit SL34 CL88','first_visible_TIA':'PF0 SL35 CL70 same','other_bus_effects':'No visible PF timing difference in captured scene','status':'PASS_BOUNDED','source':'ANALYSIS/NATURAL_ROOMLOAD_A_B_TIMERS_AND_BUS.json'},
{'id':'RoomStoneY_X5','valid_index':'II-01 room index5 FR5872','local_delta_cpu_cycles':+1,'observed_next_timer':'first INTIM0x0c, common WaitVB exit SL34 CL88','first_visible_TIA':'PF0 SL35 CL70 same','other_bus_effects':'No visible PF timing difference in captured scene','status':'PASS_BOUNDED','source':'ANALYSIS/NATURAL_ROOMLOAD_A_B_TIMERS_AND_BUS.json'},
{'id':'TitleLeftPF2_Y2Y3','valid_index':'Title Y2,Y3; previous independent verification only','local_delta_cpu_cycles':+1,'observed_next_timer':'Previously bounded / no new retest','first_visible_TIA':'64 prior original TIA writes +3 colorclocks, minimum right PF margin32 colorclocks; 0 pixel differences','other_bus_effects':'Data unchanged','status':'PRIOR_INDEPENDENT_PASS_BOUNDED','source':'PRIOR_ARCHIVE_VERIFICATION/ANALYSIS/TITLE_64_TIA_REAL_BUS_DEADLINES.json'},
];csvout('RELOCATION_CONSEQUENCE_MATRIX.csv',matrix)
# machine test matrix statuses, classifications and exact raw evidence
m=[]
def add(id,role,kind,sha,scenario,tool,status,evid,scope,notes=''):
 assert evid or status in ('INCONCLUSIVE','NOT_RUN','PRIOR_VERIFIED');m.append({'test_id':id,'measurement_role':role,'evidence_class':kind,'rom_sha256':sha,'tool_sha256':tool,'scenario':scenario,'status':status,'raw_evidence_path':evid,'scope':scope,'limits':notes})
add('INTAKE_ALL_ZIPS','CURRENT','SOURCE_ONLY',LAB,'HEALTH/VERIFICATION/PACHINKO archive ZIP hashes manifests', 'python3 hashlib zipfile','PASS','PROVENANCE/ARCHIVE_INTAKE.json','3 archives full CRC and payload manifests')
add('NATURAL_BANK1_LAB','CURRENT','SOURCE_GUIDED_CONTROLLER',LAB,'II-01 frame5880, caller→FFF7→bank1→FFF9→caller',GO,'PASS_BOUNDED','EVIDENCE/BANK1_NATURAL/natural_bank1_LAB_raw.log','1 full 577-clock native CPU bus trace','only one natural act II bank1 state')
add('NATURAL_BANK1_RC1','CURRENT','SOURCE_GUIDED_CONTROLLER',RCS,'II-01 frame5880 matched same prefix',GO,'PASS_BOUNDED','EVIDENCE/BANK1_NATURAL/natural_bank1_RC1_raw.log','1 full 577-clock native CPU bus trace')
add('RC1_BANK_PILOT_INVALID','CURRENT','FAIL_HARNESS_CORRECTED',RCS,'Initial RC1 comparison inherited LAB caller PC F708',GO,'FAIL_HARNESS_CORRECTED','EVIDENCE/INVALID_PILOTS_AND_TIMEOUTS/natural_bank1_RC1_wrong_PC_INVALID.log','invalid initial RC1 breakpoint; retested corrected at F706')
add('OWL_FRI_NATURAL_LAB','CURRENT','NATURAL_CONTROLLER',LAB,'FRI BCS taken frame2142→WaitVB→first PF',GO,'PASS_BOUNDED','EVIDENCE/OWL_CONTINUATION/natural_owl_continuation_LAB_raw.log','natural taken BCS plus next frame 262')
add('OWL_FRI_NATURAL_RC1','CURRENT','NATURAL_CONTROLLER',RCS,'FRI BCS taken frame2142→WaitVB→first PF',GO,'PASS_BOUNDED','EVIDENCE/OWL_CONTINUATION/natural_owl_continuation_RC1_raw.log','natural taken BCS plus next frame 262')
for v in ('RC1','LAB'):
 for frame,x,name in [(964,1,'GeoMapHi'),(2497,2,'GeoMapHi'),(4483,4,'RoomStoneY'),(5872,5,'RoomStoneY')]:
  add(f'LOAD_{v}_FR{frame}','CURRENT','SOURCE_GUIDED_CONTROLLER',RCS if v=='RC1' else LAB,f'Natural room-index X{x} {name}, full timers and TIA',GO,'PASS_BOUNDED',f'EVIDENCE/ROOM_LOAD_TIMER/roomload_fullchain_{v}_raw.log','one naturally selected full frame 262 + real INTIM/VBLANK/PF','4 rows use same original 5880-frame transport per variant; not four independent full campaigns')
for v in ('LAB','RC1','PR47'):
 add('X9_'+v,'CURRENT','NATURAL_CONTROLLER',LAB if v=='LAB' else RCS if v=='RC1' else '5b8315512bf274398c3d2f4622dc96e081d1481d93b2c8adaf6411de2e2a0ed5',f'actual fireX9, fresh HUD trace, negative PR47',GO,'EXPECTED_NEGATIVE_FAIL' if v=='PR47' else 'PASS_BOUNDED',f'EVIDENCE/NEGATIVE_CONTROLS/natural_x9_instrumented_{v}.log','2 TV observations, 262 for LAB/RC1 or 263 PR47')
for p in sorted((ROOT/'EVIDENCE/TERMINAL_RASTER').glob('*/result.json')):
 x=json.loads(p.read_text());add('RASTER_'+x['scenario'],'CURRENT',x['classification'],LAB,x['scenario'],GO,'PASS_BOUNDED',str((p.parent/'raw.log').relative_to(ROOT)),'1 focused native Gopher frame, 2 262-line samples','9/10 cases forced diagnostic; cannot imply player-reachable')
for var in ('RC1','LAB'):
 for run in (1,2):
  add(f'FRI_PCM_{var}_{run}','CURRENT','NATURAL_CONTROLLER',RCS if var=='RC1' else LAB,'FRI CLOG left Difficulty B, 2400 Stella frames',ST,'PASS_BOUNDED',f'EVIDENCE/FRI_AUDIO/{var}_{run}/tia_audio.wav','2400 real callbacks; 1,257,076 stereo frames','strict A/A2 or B/B2 PCM nondeterministic')
for v in ('RC1','LAB'):add(f'FRI_TIA_SOUND_{v}','CURRENT','NATURAL_CONTROLLER',RCS if v=='RC1' else LAB,'FRI frame2100–2142 258 real six audio register bus writes',GO,'PASS_BOUNDED',f'EVIDENCE/FRI_AUDIO/fri_tia_audio_registers_{v}.log','258 actual TIA sound bus writes, 43 distinct frames','six 3-clock timing shifts in frame2142 LAB')
add('FRI_AUDIO_STRICT_AB','CURRENT','INCONCLUSIVE',LAB,'FRI PCM A/A2/B/B2 comparator',ST,'INCONCLUSIVE','ANALYSIS/FRI_AUDIO_ORACLE.json','Both same-ROM pairs differ; no attributable LAB-specific PCM mismatch')
add('STACK_MAX5_TO4','PRIOR_INDEPENDENT_VERIFICATION','SOURCE_AND_NATURAL_CPU_BUS',LAB,'5→4 valid-source JSR, actual I01 frame124','native Gopher + static CFG','PASS_CONDITIONAL','PRIOR_ARCHIVE_VERIFICATION/ANALYSIS/CFG_LAB_BEST.json','full valid graph with source-valid pointers','not arbitrary corrupted RAM proof')
add('FULL_GAME_EQUAL','PRIOR_INDEPENDENT_VERIFICATION','SOURCE_GUIDED_CONTROLLER',LAB,'15/15 rooms, 19652 frames / 20,594,248 int16 PCM',ST,'PASS_BOUNDED','PRIOR_ARCHIVE_VERIFICATION/REPORTS/INDEPENDENT_LAB_VERIFICATION_REPORT.md','source guided, not human blind play','previous experiment not rerun here')
add('FULL_RAM_MATRIX_AND_IDLE','PRIOR_INDEPENDENT_VERIFICATION','SOURCE_GUIDED_CONTROLLER',LAB,'540000 idle +15 causal/select/wins +50010 FRI',ST,'PASS_BOUNDED','PRIOR_ARCHIVE_VERIFICATION/REPORTS/INDEPENDENT_LAB_VERIFICATION_REPORT.md','previous raw separate archive, not rerun')
add('PACHINKO_ADVERSARIAL','PRIOR_PACHINKO','SOURCE_GUIDED_CONTROLLER',LAB,'105 scenarios/ROM, 3255 checkpoints',ST,'PASS_BOUNDED','PRIOR_ARCHIVE_PACHINKO/REPORTS/01_PACHINKO_FINAL_REPORT.md','not independent verifier new work')
add('GLOBAL_TIMING','CURRENT','SOURCE_ONLY',LAB,'All source-valid combined terminal Presence/echo/pending/beat timing',GO,'INCONCLUSIVE','ANALYSIS/BEAM_DEADLINE_LEDGER.csv','No full reachable-state proof')
add('SECOND_NATURAL_BANK1','CURRENT','NOT_RUN',LAB,'Different natural act II bank1 state with echo etc',GO,'NOT_RUN','','One complete matched natural state already captured; no second distinct')
add('HUMAN_HARDWARE','CURRENT','NOT_RUN',LAB,'Human cold play, art, audio, physical original Atari and RetroN77','NONE','NOT_RUN','','No human or hardware sessions')
csvout('TEST_MATRIX.csv',m)
print(json.dumps({'test_matrix_rows':len(m),'bank_events':len(bank),'timer_rows':len(rrows),'beam_rows':len(beam),'relocation_consequence_rows':len(matrix),'status_counts':{x:sum(a['status']==x for a in m) for x in set(a['status'] for a in m)}},indent=2))
