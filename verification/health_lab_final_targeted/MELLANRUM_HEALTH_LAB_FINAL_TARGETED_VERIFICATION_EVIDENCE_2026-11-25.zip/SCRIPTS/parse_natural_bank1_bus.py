#!/usr/bin/env python3
"""Gopher2600 v0.57.2/unreleased actual QUANTUM CLOCK/ONSTEP TV,CPU,BUS DETAIL parser.
Report raw observed CPU bus, distinguishing natural read/write from PEEK and repeated
three-colorclock reports. Never manufacture missing observations.
"""
import sys,re,json,pathlib,hashlib,collections
p=pathlib.Path(sys.argv[1]); r=p.read_text(errors='replace')
rec=re.compile(r'FR=(\d+) SL=(\d+) CL=(-?\d+)\nPC=([0-9a-f]{4}) A=([0-9a-f]{2}) X=([0-9a-f]{2}) Y=([0-9a-f]{2}) SP=([0-9a-f]{2}) SR=([^\n]+)\nAddress: [^\n]*\[([0-9a-f]{4})\]\s+Data: [^\n]*\[([0-9a-f]{4})\]\n([^\n]+)',re.I)
rows=[]
for m in rec.finditer(r):
 fr,sl,cl,pc,a,x,y,sp,sr,addr,data,kind=m.groups()
 rows.append(dict(frame=int(fr),scanline=int(sl),cl=int(cl),colorclock=int(cl)+68,pc=pc.lower(),a=a.lower(),x=x.lower(),y=y.lower(),sp=sp.lower(),sr=sr,addr=addr.lower(),data=data[-2:].lower(),type=kind.strip()))
sprows=[a for a in rows if a['sp']]
# For 3-colorclock period repetition deduplicate identical contiguous activity only.
dedup=[]
for row in rows:
 if dedup and all(row[k]==dedup[-1][k] for k in ('pc','sp','addr','data','type')) and row['frame']==dedup[-1]['frame'] and row['scanline']==dedup[-1]['scanline'] and row['cl']-dedup[-1]['cl']<=3:
  continue
 dedup.append(row)
write=[e for e in dedup if 'writing' in e['type'].lower() and 0x1f5<=int(e['addr'],16)<=0x1ff]
read=[e for e in dedup if 'reading' in e['type'].lower() and 0x1f5<=int(e['addr'],16)<=0x1ff]
hotspots=[e for e in dedup if e['addr'] in ('fff6','fff7','fff8','fff9') and 'reading' in e['type'].lower()]
# Snapshot PEEK lines only in raw text; no bus equivalence claimed.
snaps=[]
for section in re.split(r'(?=0x01f5 \[mirror of)',r):
 pairs=re.findall(r'0x01(f[5-9a-f]) \[mirror of 0x00f[5-9a-f]\] \(RAM\) = 0x([0-9a-f]{2})',section,re.I)
 if len(pairs)>=11:snaps.append({k.lower():v.lower() for k,v in pairs})
cpu_notes=re.findall(r'PC=([0-9a-f]{4}) A=([0-9a-f]{2}) X=([0-9a-f]{2}) Y=([0-9a-f]{2}) SP=([0-9a-f]{2}) SR=([^\n]+)',r,re.I)
# hardware input provenance: assert original frame=5880 room=5/act=2 before this frame.
variant='RC1' if 'RC1' in p.name else 'LAB'
caller={'RC1':'f706','LAB':'f708'}[variant]
ret={'RC1':'f709','LAB':'f70b'}[variant]
started=f'break on PC->0x{caller} & Bank->3' in r
rtn=f'PC={ret}' in r and 'PC=ff99' in r
fr=sorted(set(e['frame'] for e in rows))
result={'raw_file':p.name,'raw_sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'raw_bytes':p.stat().st_size,
'quantum_clock_bus_samples':len(rows),'dedup_bus_cycles':len(dedup),'event_frame_indices':fr,
'cpu_SP_min_observed':min([int(q['sp'],16) for q in rows],default=None),
'stack_bus_writes':write,'stack_bus_reads':read,
'bank_hotspot_CPU_reads':hotspots,
'guard_or_spare_F5_F7_bus_writes':[x for x in write if int(x['addr'],16)<=0x1f7],
'stack_11_byte_peek_snapshots':snaps,
'start_break_f708':started,'return_ff99_f70b':rtn,'frames_262':len(re.findall(r'top:\s*\d+, bottom:\s*\d+, total:\s*262',r)),
'errors':[x for x in r.splitlines() if 'unrecognised' in x.lower() or 'error:' in x.lower()][:30],
'valid_natural':bool(started and rtn and any(x['addr']=='fff7' for x in hotspots) and any(x['addr']=='fff9' for x in hotspots) and not any(int(x['addr'],16)<0x1f8 for x in write) and len(rows)>300)}
print(json.dumps({k:v for k,v in result.items() if k not in ('stack_bus_reads','stack_bus_writes','bank_hotspot_CPU_reads')},indent=2)[:2300]);out=pathlib.Path(sys.argv[2]);out.write_text(json.dumps(result,indent=2))
