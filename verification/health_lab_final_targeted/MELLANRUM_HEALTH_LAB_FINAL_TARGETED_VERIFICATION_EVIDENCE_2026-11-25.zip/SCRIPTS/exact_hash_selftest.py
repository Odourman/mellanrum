from pathlib import Path
import hashlib
BASE=Path(__file__).resolve().parents[1]
known={'ROMS/RC1.bin':'456005ed691860b32c44b79f2a71666f622b005f5a798eadf9b549c59cff13bd','ROMS/LAB_BEST.bin':'8a59b84eb5151f78d40e6943c854d7e42c166b531aee3d40432182d32dcdf03b','SOURCE_SNAPSHOT/RC1/rom/src/main.asm':'758d5ad2eb14942d4b2ca6263aa2942ba61f927285291fa51bbedf4e8ff1f01d','SOURCE_SNAPSHOT/LAB_BEST/rom/src/main.asm':'3246d67a40470454eb56c38f2f4c32fb34ccb4ff38ed796ccb10cf00a647d53e'}
for f,exp in known.items():
 p=BASE/f; actual=hashlib.sha256(p.read_bytes()).hexdigest();assert actual==exp,(f,actual,exp);print('PASS',f,actual)
