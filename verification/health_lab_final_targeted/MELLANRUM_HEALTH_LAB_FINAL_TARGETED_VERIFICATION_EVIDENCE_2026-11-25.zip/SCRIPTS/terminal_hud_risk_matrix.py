#!/usr/bin/env python3
"""Explicitly diagnostic limited HUD/terminal matrix, original LAB ROM unchanged."""
from pathlib import Path
import subprocess,hashlib,re,json,time
root=Path('/mnt/data/LAB_FINAL_TARGETED')
core=root/'work/gopher2600_pinned';rom=root/'verification/SPECIMEN/LAB_STACK_INLINE_PADDED_B_EXPERIMENT_ONLY.bin'
assert hashlib.sha256(rom.read_bytes()).hexdigest()=='8a59b84eb5151f78d40e6943c854d7e42c166b531aee3d40432182d32dcdf03b'
raw=(root/'verification/EVIDENCE/NATURAL_X9/LAB_BEST/commands.txt').read_text().splitlines();base=raw[:raw.index('QUANTUM INSTRUCTION')]
# No RAM writes in the one genuinely natural controller test. All other cases explicitly forced transient RIOT diagnostic.
cases={
 'NATURAL_X9':[],
 'CURSOR1_FIRE9':['POKE 0x00cc 1'],
 'ACK_ACCEPTED':['POKE 0x00d5 6','POKE 0x00d6 1'],
 'ACK_DENIED':['POKE 0x00d5 6','POKE 0x00d6 2'],
 'PRESENCE_INTERCEPT':['POKE 0x00db 2','POKE 0x00dd 1','POKE 0x00d5 6','POKE 0x00d6 3'],
 'PENDING_OLD_TARGET':['POKE 0x00d2 1','POKE 0x00f3 4','POKE 0x00d6 1','POKE 0x00d5 6'],
 'PENDING_DENIED_SECOND':['POKE 0x00d2 1','POKE 0x00d5 6','POKE 0x00d6 2'],
 'PRESENCE_ECHO_PHASE':['POKE 0x00db 2','POKE 0x00c4 1','POKE 0x00d5 6','POKE 0x00d6 3'],
 'OWL_BEAT_55':['POKE 0x00c7 55','POKE 0x00bb 2'],
 'OWL_BEAT_54':['POKE 0x00c7 54','POKE 0x00bb 3'],
}
for nm,forced in cases.items():
 folder=root/'EVIDENCE/TERMINAL_RASTER'/nm;folder.mkdir(parents=True,exist_ok=True)
 cmd=base+forced+['PEEK 0x00b8 0x00b9 0x00ba 0x00cc 0x00f2 0x00f3 0x00d2 0x00d5 0x00d6 0x00db 0x00dd 0x00c4 0x00c7','TRACE STRICT 0x10','TRACE STRICT 0x02','TRACE STRICT 0x0b','TRACE STRICT 0x0d','TRACE STRICT 0x0e','TRACE STRICT 0x0f','TRACE STRICT 0x1b','TRACE STRICT 0x1c','TRACE STRICT 0x04','TRACE STRICT 0x2a','ONTRACE TV,CPU','QUANTUM INSTRUCTION','ONSTEP TV,CPU','ONSTEP ON','STEP FRAME','ONSTEP OFF','ONTRACE OFF','TV FRAME','CPU','PEEK 0x00b8 0x00b9 0x00ba 0x00cc 0x00f2 0x00f3 0x00d2 0x00d5 0x00d6 0x00db 0x00dd 0x00c4 0x00c7']
 (folder/'commands.txt').write_text('\n'.join(cmd)+'\n');t=time.time()
 try:
  p=subprocess.run([str(core),'HEADLESS',str(rom)],input='SCRIPT '+str(folder/'commands.txt')+'\n',capture_output=True,text=True,timeout=28)
  out=p.stdout+p.stderr;ret=p.returncode;err=None
 except subprocess.TimeoutExpired as e:
  out=(e.stdout or b'').decode(errors='replace')+(e.stderr or b'').decode(errors='replace');ret=None;err='TIMEOUT'
 (folder/'raw.log').write_text(out)
 totals=[int(x) for x in re.findall(r'total:\s*(\d+)',out)];resp=[]
 for m in re.finditer(r'FR=(\d+) SL=(\d+) CL=(-?\d+)\nPC=([0-9a-f]{4})[^\n]*\nwrite 0x([0-9a-f]{2}) to 0x0010 \(RESP0\)',out,re.I): resp.append({'frame':int(m[1]),'sl':int(m[2]),'cl':int(m[3]),'pc_after':m[4],'data':m[5]})
 found=re.findall(r'FR=(\d+) SL=(\d+) CL=(-?\d+)\nPC=f9a5',out,re.I)
 peeks=re.findall(r'0x00(?:cc|f2|d2|d5|d6|db|dd|c4|c7) \(RAM\) = 0x([0-9a-f]{2})',out,re.I)
 result={'scenario':nm,'rom_sha256':hashlib.sha256(rom.read_bytes()).hexdigest(),'emulator_sha256':hashlib.sha256(core.read_bytes()).hexdigest(),'classification':'NATURAL_CONTROLLER' if not forced else 'FORCED_RAM_DIAGNOSTIC','forced_commands':forced,'command_sha':hashlib.sha256((folder/'commands.txt').read_bytes()).hexdigest(),'raw_sha':hashlib.sha256(out.encode()).hexdigest(),'exit':ret,'error':err,'seconds':round(time.time()-t,2),'raster_totals':totals,'resp0_bus':resp,'hud_wsync_pc_f9a5_instructions':found[:15],'hud_wsync_visits':len(found),'genuine_6507_instruction_samples':len(re.findall(r'PC=[0-9a-f]{4} A=',out,re.I)),'harness_errors':re.findall(r'.*unrecognised.*',out,re.I),'state_peek_values_hex_stream':peeks,'status':'PASS_BOUNDED' if ret==0 and totals and totals[-1]==262 and any(x['sl']==214 for x in resp) and not re.search('unrecognised',out,re.I) else 'INCONCLUSIVE'}
 (folder/'result.json').write_text(json.dumps(result,indent=2));print(nm,result['status'],totals,'resp',resp[-1:] if resp else None,'seconds',result['seconds'],flush=True)
