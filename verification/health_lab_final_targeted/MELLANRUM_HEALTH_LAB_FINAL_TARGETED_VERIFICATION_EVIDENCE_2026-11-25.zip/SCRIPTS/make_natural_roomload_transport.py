"""Compress known controller frames, instrument four real LoadRoom paths.
Naturally reaches II-01 after 5880 frames. No RAM POKE. Pinned original ROMs.
"""
from pathlib import Path
p=Path('/mnt/data/LAB_FINAL_TARGETED/verification/EVIDENCE/GOPHER_FULL/commands.txt').read_text().splitlines()
out=Path('/mnt/data/LAB_FINAL_TARGETED/work/scripts');endmarker='screensroom_05.png'
targets={963:(1,964),2496:(2,2497),4482:(4,4483),5871:(5,5872)}
for variant in ('LAB','RC1'):
  cmds=[];frame=0;pending=0;injects=[]
  def flush():
   global frame,pending
   if pending:
    frame+=pending
    cmds.extend([f'BREAK FR {frame}','RUN',f'BREAK DROP FR {frame}']);pending=0
  for s in p:
   if s.startswith('SCREENSHOT') and s.endswith(endmarker):flush();break
   if s=='STEP FRAME': pending+=1
   elif s.startswith(('VERSION','CARTRIDGE HASH','PERIPHERAL','PANEL','STICK LEFT')):
    flush();cmds.append(s)
    if s=='STICK LEFT FIRE' and frame in targets:
     x,fr=targets[frame];injects.append((frame,x))
     cmds+=['TRACE STRICT 0x0296','TRACE STRICT 0x0284','TRACE STRICT 0x0001','ONTRACE TV,CPU',f'BREAK PC 0xf2d5 & BANK 3 & X {x}', 'RUN','CPU','TV','PEEK 0x00b8 0x00b9 0x00ba 0x00c6', 'STEP INSTRUCTION','CPU','TV','CLEAR BREAKS', f'BREAK PC 0xf2ed & BANK 3 & X {x}','RUN','CPU','TV','STEP INSTRUCTION','CPU','TV','CLEAR BREAKS','BREAK PC 0xf05e & BANK 3','RUN','CPU','TV','STEP INSTRUCTION','CPU','TV','CLEAR BREAKS','BREAK PC 0xf063 & BANK 3','RUN','CPU','TV','STEP INSTRUCTION','CPU','TV','STEP INSTRUCTION','STEP INSTRUCTION','CPU','TV','CLEAR BREAKS','BREAK PC 0xf790 & BANK 3','RUN','CPU','TV','CLEAR BREAKS','TRACE STRICT 0x000d','TRACE STRICT 0x000e','TRACE STRICT 0x000f',f'BREAK FR {fr+1}','RUN','TV FRAME','CPU','PEEK 0x00b8 0x00b9 0x00ba','CLEAR BREAKS','CLEAR TRACES']
  assert frame==5880 and len(injects)==4,(frame,injects)
  cmds+=['TV FRAME','CPU','PEEK 0x00b8 0x00b9 0x00ba']
  target=out/f'natural_roomload_fullchain_{variant}.script';target.write_text('\n'.join(cmds)+'\n');print(variant,frame,len(cmds),injects,target)
