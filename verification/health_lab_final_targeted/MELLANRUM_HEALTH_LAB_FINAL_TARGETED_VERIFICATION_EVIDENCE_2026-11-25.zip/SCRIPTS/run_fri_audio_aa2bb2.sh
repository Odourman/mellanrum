#!/usr/bin/env bash
set -euo pipefail
ROOT=/mnt/data/LAB_FINAL_TARGETED
CAP="$ROOT/health/MELLANRUM_HEALTH_OPTIMIZATION_LAB_EVIDENCE/TEST_TOOLS/libretro_stella_capture.py"
CORE="$ROOT/pachinko/TOOLS/stella_libretro.so"
export GITHUB_SHA=LAB_FINAL_TARGETED_ORIGINAL_SOURCE_REFERENCE
for VARIANT in RC1 LAB; do
  if [[ $VARIANT == RC1 ]]; then ROM="$ROOT/verification/REFERENCE/RC1.bin"; HASH=456005ed691860b32c44b79f2a71666f622b005f5a798eadf9b549c59cff13bd; else ROM="$ROOT/verification/SPECIMEN/LAB_STACK_INLINE_PADDED_B_EXPERIMENT_ONLY.bin"; HASH=8a59b84eb5151f78d40e6943c854d7e42c166b531aee3d40432182d32dcdf03b; fi
  for RUN in 1 2; do
    OUT="$ROOT/EVIDENCE/FRI_AUDIO/${VARIANT}_${RUN}"; mkdir -p "$OUT"
    echo "RUN START $VARIANT $RUN $(date -u -Iseconds)" >> "$ROOT/work/logs/fri_audio_runner.log"
    export MELLANRUM_ROM_SHA="$HASH"
    timeout 110s python "$CAP" --core "$CORE" --rom "$ROM" --out "$OUT" --frames 2400 --audio-frames 2400 --left B --seed 241125 --profile CLOG --snap-every 600 --sample-every 100 > "$OUT/stdout.log" 2> "$OUT/stderr.log"
    CODE=$?
    printf '%s\n' "$CODE" > "$OUT/exit_code.txt"
    echo "RUN END $VARIANT $RUN $CODE $(date -u -Iseconds)" >> "$ROOT/work/logs/fri_audio_runner.log"
  done
done
