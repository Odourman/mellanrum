#!/usr/bin/env python3
"""FRI A/A2/B/B2 real Stella PCM payloads and genuine Gopher TIA audio commands."""
from pathlib import Path
import json,hashlib,wave,numpy as np,re
root=Path('/mnt/data/LAB_FINAL_TARGETED/EVIDENCE/FRI_AUDIO')
out={}
for var in ('RC1','LAB'):
 for run in (1,2):
  key=f'{var}_{run}';p=root/key; assert (p/'exit_code.txt').read_text().strip()=='0'
  r=json.loads((p/'result.json').read_text());w=wave.open(str(p/'tia_audio.wav'),'rb');n=w.getnframes();ch=w.getnchannels();hz=w.getframerate();raw=w.readframes(n);w.close()
  assert n==1257076 and ch==2 and hz==31440 and len(raw)==n*ch*2
  frames=[json.loads(x) for x in (p/'frame_samples.jsonl').read_text().splitlines()]
  out[key]={'emulator':r['core'],'rom_sha256':r['rom_sha256'],'fresh_os_process':True,'emulated_frames':r['emulated_frames'],'video_callbacks':r['video_callbacks'],'audio_stereo_frames':n,'int16_values':len(raw)//2,'audio_callback_frames_reported':r['audio_samples'],'channels':ch,'rate_hz':hz,'raw_pcm_sha256':hashlib.sha256(raw).hexdigest(),'wav_sha256':hashlib.sha256((p/'tia_audio.wav').read_bytes()).hexdigest(),'input_events_sha256':hashlib.sha256((p/'controller_frame_events.json').read_bytes()).hexdigest(),'ram_frame_samples':frames,'raw_pcm_path':str((p/'tia_audio.wav').relative_to(root.parent.parent))}
  out[key]['_samples']=np.frombuffer(raw,dtype='<i2').astype(np.int32)
comparisons={}
for a,b in [('RC1_1','RC1_2'),('LAB_1','LAB_2'),('RC1_1','LAB_1'),('RC1_2','LAB_2')]:
 x,y=out[a],out[b];assert len(x['_samples'])==len(y['_samples']);diff=x['_samples']-y['_samples'];non=np.flatnonzero(diff)
 checkpoints=[{'frame':p['frame'],'same_pixels':p['framebuffer_sha256']==q['framebuffer_sha256'],'same_raw_ram_128b':p['ram_sha256']==q['ram_sha256']} for p,q in zip(x['ram_frame_samples'],y['ram_frame_samples'])]
 comparisons[f'{a}_vs_{b}']={'raw_pcm_exact_equal':len(non)==0,'int16_total':len(diff),'different_int16_count':len(non),'first_different_int16_index':int(non[0]) if len(non) else None,'peak_absolute_int16_difference':int(np.abs(diff).max()),'rms_difference':float(np.sqrt(np.mean(diff.astype(float)**2))),'sample_checkpoints':checkpoints,'all_sampled_framebuffers_equal':all(z['same_pixels'] for z in checkpoints),'identical_rom':a.split('_')[0]==b.split('_')[0]}
for v in out.values():del v['_samples'];del v['ram_frame_samples']
trace={}
for var in ('RC1','LAB'):
 p=root/f'fri_tia_audio_registers_{var}.log';assert (root/f'fri_tia_audio_registers_{var}.exit').read_text().strip()=='0'
 t=p.read_text();rx=re.compile(r'FR=(\d+) SL=(\d+) CL=(-?\d+)\nPC=[^\n]+\nwrite 0x([0-9a-f]+) to 0x(001[5-9a]) \((AUD[CFV][01])\) \(TIA\)',re.I)
 ev=[{'frame':int(m[1]),'scanline':int(m[2]),'colorclock':int(m[3])+68,'cl':int(m[3]),'data':m[4],'register_addr':m[5],'register':m[6]} for m in rx.finditer(t)]
 assert len(ev)==258 and len(set(x['frame'] for x in ev))==43
 trace[var]={'log_sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'audio_cpu_bus_write_events':len(ev),'first_frame':2100,'last_frame':2142,'events':ev}
rc=trace['RC1']['events'];lb=trace['LAB']['events'];errors=[]
for i,(a,b) in enumerate(zip(rc,lb)):
 if a!=b:errors.append({'i':i,'rc1':a,'lab':b,'delta_colorclocks_LAB_minus_RC1':(b['scanline']-a['scanline'])*228+b['colorclock']-a['colorclock']})
assert len(errors)==6 and all(x['delta_colorclocks_LAB_minus_RC1']==-3 for x in errors)
for v in trace.values():del v['events']
summary={'status':'FRI_RAW_PCM_NONDETERMINISTIC_WITHIN_SAME_ROM / A_B_STRICT_PCM_INCONCLUSIVE','capture_pipeline':'pinned native Stella libretro 8.0_pre 8dd5600 / separate OS process per run / fresh core load / identical deterministic source input CLOG left Difficulty B seed 241125','runs':out,'comparisons':comparisons,'gopher_native_actual_TIA_audio_bus':{'two_roms':trace,'raw_event_data_and_positions_equal_before_frame2142':True,'frame2142_identical_register_values_but_shifted_earlier_LAB':True,'shifted_register_count':6,'delta_colorclocks_LAB_vs_RC1':-3,'actual_differences':errors},'interpretation':'SAME_ROM PCM variation blocks strict AB attribution. Actual LAB-specific 3-clock-earlier six sound register writes at naturally taken OwlTryNext frame2142 are real CPU/TIA bus timing differences, data equal; not proven audible defect. Visible PF timing equal after WaitVBlank.'}
(root/'FRI_AUDIO_ORACLE.json').write_text(json.dumps(summary,indent=2,ensure_ascii=False)+'\n')
print(json.dumps({'status':summary['status'],'runs':{k:{j:v for j,v in x.items() if j!='emulator'} for k,x in out.items()},'summary':{k:{j:v for j,v in z.items() if j!='sample_checkpoints'} for k,z in comparisons.items()},'tia_writes_shifted':len(errors)},indent=2))
